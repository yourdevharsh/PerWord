import { useMemo, useRef, useState } from "react";
import type { ChangeEvent, DragEvent } from "react";

type FileItem = {
  id: string;
  file: File;
};

type TaskDraft = {
  id: string;
  name: string;
  inputFiles: FileItem[];
  outputFiles: FileItem[];
  details: string;
  saved: boolean;
};

function createTask(): TaskDraft {
  return {
    id: crypto.randomUUID(),
    name: "",
    inputFiles: [],
    outputFiles: [],
    details: "",
    saved: false,
  };
}

function PlusIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M12 5v14M5 12h14" />
    </svg>
  );
}

function ArrowRightIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M4 12h15M13 6l6 6-6 6" />
    </svg>
  );
}

function CloseIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="m7 7 10 10M17 7 7 17" />
    </svg>
  );
}

function FileIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M7 3.75h7l4 4v12.5H7z" />
      <path d="M14 3.75v4h4M9.5 12h5M9.5 15h5" />
    </svg>
  );
}

function formatBytes(size: number) {
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

function fileKey(file: File) {
  return `${file.name}-${file.size}-${file.lastModified}`;
}

function FilesPanel({
  title,
  files,
  onAdd,
  onRemove,
}: {
  title: "Input" | "Output";
  files: FileItem[];
  onAdd: (files: FileList | File[]) => void;
  onRemove: (id: string) => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleInput = (event: ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      onAdd(event.target.files);
      event.target.value = "";
    }
  };

  const handleDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragging(false);
    if (event.dataTransfer.files.length) onAdd(event.dataTransfer.files);
  };

  const layoutClass = useMemo(() => {
    const count = Math.min(files.length, 5);
    return `file-grid count-${count}`;
  }, [files.length]);

  return (
    <section className="files-panel">
      <div className="panel-label">{title}</div>
      <div
        className={`files-surface ${isDragging ? "is-dragging" : ""}`}
        onDragEnter={(event) => {
          event.preventDefault();
          setIsDragging(true);
        }}
        onDragOver={(event) => event.preventDefault()}
        onDragLeave={(event) => {
          if (event.currentTarget === event.target) setIsDragging(false);
        }}
        onDrop={handleDrop}
      >
        {files.length === 0 ? (
          <button className="empty-upload" type="button" onClick={() => inputRef.current?.click()}>
            <span className="empty-upload-icon">
              <PlusIcon />
            </span>
            <span className="empty-upload-title">Add files</span>
            <span className="empty-upload-copy">Drop files here or choose from your device</span>
          </button>
        ) : (
          <div className={layoutClass}>
            {files.map(({ id, file }) => (
              <article className="file-card" key={id}>
                <div className="file-card-top">
                  <span className="file-type-icon">
                    <FileIcon />
                  </span>
                  <button
                    className="icon-button"
                    type="button"
                    aria-label={`Remove ${file.name}`}
                    onClick={() => onRemove(id)}
                  >
                    <CloseIcon />
                  </button>
                </div>
                <div className="file-name" title={file.name}>
                  {file.name}
                </div>
                <div className="file-meta">{formatBytes(file.size)}</div>
              </article>
            ))}
            <button className="add-more-card" type="button" onClick={() => inputRef.current?.click()}>
              <PlusIcon />
              <span>Add more</span>
            </button>
          </div>
        )}
        <input ref={inputRef} className="visually-hidden" type="file" multiple onChange={handleInput} />
      </div>
    </section>
  );
}

function App() {
  const [tasks, setTasks] = useState<TaskDraft[]>([]);

  const addTask = () => setTasks((current) => [...current, createTask()]);

  const updateTask = (id: string, patch: Partial<TaskDraft>) => {
    setTasks((current) => current.map((task) => (task.id === id ? { ...task, ...patch } : task)));
  };

  const addFiles = (taskId: string, side: "inputFiles" | "outputFiles", incoming: FileList | File[]) => {
    const incomingFiles = Array.from(incoming);
    setTasks((current) =>
      current.map((task) => {
        if (task.id !== taskId) return task;

        const existing = task[side];
        const existingKeys = new Set(existing.map(({ file }) => fileKey(file)));
        const next = incomingFiles
          .filter((file) => !existingKeys.has(fileKey(file)))
          .map((file) => ({ id: crypto.randomUUID(), file }));

        return { ...task, [side]: [...existing, ...next], saved: false };
      }),
    );
  };

  const removeFile = (taskId: string, side: "inputFiles" | "outputFiles", fileId: string) => {
    setTasks((current) =>
      current.map((task) =>
        task.id === taskId
          ? { ...task, [side]: task[side].filter(({ id }) => id !== fileId), saved: false }
          : task,
      ),
    );
  };

  const saveTask = (task: TaskDraft) => {
    if (!task.name.trim()) return;
    updateTask(task.id, { saved: true });
  };

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">PerWord</div>
      </header>

      <main className="main-content">
        <div className="intro">
          <p className="eyebrow">Teach once. Reuse the task.</p>
          <h1>What should PerWord learn?</h1>
          <p className="intro-copy">
            Give an example input, the desired output, and the details that explain the change.
          </p>
        </div>

        {tasks.map((task, index) => (
          <section className="task-section" key={task.id}>
            <div className="task-number">Task {String(index + 1).padStart(2, "0")}</div>
            <input
              className="task-name"
              type="text"
              placeholder="Name this task"
              value={task.name}
              onChange={(event) => updateTask(task.id, { name: event.target.value, saved: false })}
            />

            <div className="flow-layout">
              <FilesPanel
                title="Input"
                files={task.inputFiles}
                onAdd={(files) => addFiles(task.id, "inputFiles", files)}
                onRemove={(fileId) => removeFile(task.id, "inputFiles", fileId)}
              />

              <div className="flow-arrow" aria-hidden="true">
                <ArrowRightIcon />
              </div>

              <FilesPanel
                title="Output"
                files={task.outputFiles}
                onAdd={(files) => addFiles(task.id, "outputFiles", files)}
                onRemove={(fileId) => removeFile(task.id, "outputFiles", fileId)}
              />
            </div>

            <textarea
              className="details-input"
              placeholder="Details — describe what should change"
              rows={4}
              value={task.details}
              onChange={(event) => updateTask(task.id, { details: event.target.value, saved: false })}
            />

            <div className="task-footer">
              <div className={`save-status ${task.saved ? "visible" : ""}`} aria-live="polite">
                {task.saved ? "Task saved" : ""}
              </div>
              <button
                className="save-button"
                type="button"
                disabled={!task.name.trim()}
                onClick={() => saveTask(task)}
              >
                Save task
              </button>
            </div>
          </section>
        ))}

        <button className="add-task-button" type="button" onClick={addTask}>
          <span className="add-task-icon">
            <PlusIcon />
          </span>
          <span>{tasks.length === 0 ? "Add a task" : "Add another task"}</span>
        </button>
      </main>
    </div>
  );
}

export default App;
